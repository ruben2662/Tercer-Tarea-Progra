import java.util.LinkedList;
import java.util.Queue;

public class ColaTurnos {
    private Queue<Integer> turnos;

    public ColaTurnos() {
        turnos = new LinkedList<>();
    }

    public void agregarTurno(int numeroTurno) {
        turnos.add(numeroTurno);
        System.out.println("El Turno  " + numeroTurno + " fue agregado a la cola.");
    }

    public void atenderTurno() {
        if (turnos.isEmpty()) {
            System.out.println("No hay clientes en espera.");
        } else {
            int turnoAtendido = turnos.poll();
            System.out.println("Cliente con turno " + turnoAtendido + " atendido.");
        }
    }

    public void mostrarTurnos() {
        if (turnos.isEmpty()) {
            System.out.println("Espera.... No hay turnos en espera.");
        } else {
            System.out.println("Turnos en espera: " + turnos);
        }
    }
}