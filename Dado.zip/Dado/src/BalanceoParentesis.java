import java.util.Stack;

public class BalanceoParentesis {
    public static boolean estaBalanceado(String secuencia) {
        Stack<Character> pila = new Stack<>();

        for (int i = 0; i < secuencia.length(); i++) {
            char caracter = secuencia.charAt(i);

            if (caracter == '(' || caracter == '{' || caracter == '[') {
                pila.push(caracter);
            }
            else if (caracter == ')' || caracter == '}' || caracter == ']') {
                if (pila.isEmpty()) {
                    return false;
                }
                char ultimo = pila.pop();

                if (!coinciden(ultimo, caracter)) {
                    return false;
                }
            }
        }
        return pila.isEmpty();
    }

    private static boolean coinciden(char apertura, char cierre) {
        return (apertura == '(' && cierre == ')') ||
                (apertura == '{' && cierre == '}') ||
                (apertura == '[' && cierre == ']');
    }

    // Método main para probar
    public static void main(String[] args) {
        String[] pruebas = {"{[()]}", "{[(])}", "()", "{}[]", "(]", ""};

        for (String prueba : pruebas) {
            boolean resultado = estaBalanceado(prueba);
            System.out.println("Secuencias: " + prueba + " -> " + resultado);
        }
    }
}