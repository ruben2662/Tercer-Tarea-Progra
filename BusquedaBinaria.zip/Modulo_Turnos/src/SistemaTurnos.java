public class SistemaTurnos {
    public static void main(String[] args) {
        ColaTurnos cola = new ColaTurnos();

        cola.agregarTurno(1);
        cola.agregarTurno(2);
        cola.atenderTurno();
        cola.mostrarTurnos();

// agregamos los tiurnos, mostramos, atendemos y mostrar el turno
        cola.agregarTurno(3);
        cola.mostrarTurnos();
        cola.atenderTurno();
        cola.mostrarTurnos();
    }
}